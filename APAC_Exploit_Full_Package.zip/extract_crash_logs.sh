
#!/bin/bash

# File: extract_crash_logs.sh
# Description: Scans system crash logs for APAC exploit-related crashes (APACChannelRemapper or memmove)

LOG_DIR="$HOME/Library/Logs/DiagnosticReports"
TARGET="output_apac_patch"

echo "[*] Scanning crash logs in: $LOG_DIR"
echo

for file in "$LOG_DIR"/*.crash; do
    if grep -q "$TARGET" "$file"; then
        echo "[+] Found crash log: $file"
        grep -A20 -Ei "(APACChannelRemapper|memmove|DecodeAPACFrame)" "$file"
        echo "----------------------------------------"
    fi
done
