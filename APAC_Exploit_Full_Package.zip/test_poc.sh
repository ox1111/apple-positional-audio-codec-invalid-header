#!/bin/bash

# File: test_poc.sh
# Description: Attempt to extract APAC audio stream using FFmpeg

INPUT_FILE="IMG_0755.mov"
OUTPUT_FILE="output_apac.m4a"

echo "[*] Checking stream information..."
ffmpeg -i "$INPUT_FILE"

echo "[*] Attempting to extract APAC audio stream (Stream #1 assumed)..."
ffmpeg -i "$INPUT_FILE" -map 0:1 -c:a copy "$OUTPUT_FILE"
