
# generate_apac_test_audio.py
# This script creates a 5-channel dummy WAV file for use in APAC-related PoC testing.

import numpy as np
import soundfile as sf

# Configuration
channels = 5
samplerate = 48000
duration = 2.0  # 2 seconds
filename = "sound440hz_5ch.wav"

# Generate sine wave (440Hz tone)
t = np.linspace(0, duration, int(samplerate * duration), endpoint=False)
tone = 0.5 * np.sin(2 * np.pi * 440 * t)

# Duplicate tone across channels
data = np.column_stack([tone for _ in range(channels)])

# Save WAV file
sf.write(filename, data, samplerate, subtype='PCM_16')
print(f"[+] Created multi-channel WAV file: {filename}")
