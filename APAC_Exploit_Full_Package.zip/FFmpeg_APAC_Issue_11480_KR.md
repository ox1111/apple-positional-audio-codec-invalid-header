
# FFmpeg Enhancement 요청 #11480 분석: Apple APAC 코덱 지원 추가

## 📄 원문 요약

- **요청자**: `emcodem`
- **요청 유형**: `enhancement` (기능 개선 요청)
- **대상 버전**: `git-master`
- **키워드**: `apac`
- **설명**: iPhone 16 이후 `.mov` 파일에서 APAC(Apple Positional Audio Codec) 오디오 트랙이 포함되며, `-map 0:a`와 같은 명령어로 오디오만 추출하려 하면 **디코딩 실패** 발생.

---

## 🔍 번역 및 분석

### 🔸 문제 요약

iPhone 16 시리즈부터 `.mov` 파일에 **APAC** 공간 오디오 트랙이 삽입되고 있음. FFmpeg은 이 트랙을 인식하지만, 실제로 **지원되는 디코더가 없어 디코딩 실패**.  

명령어 예시:
```bash
ffmpeg -i C:\in\IMG_0755.mov -map 0:a C:\out\VID_IMG_0755.mov
```

출력 로그에서는 다음과 같은 에러가 발생:
- `Could not find codec parameters for stream 1`
- `Decoding requested, but no decoder found for: none`
- `Error opening output files: Invalid argument`

APAC 코덱을 디코딩할 수 없기 때문에 FFmpeg이 출력을 생성하지 못하고 종료됨.

---

## 💻 사용된 기술 스택

| 기술 구성 | 설명 |
|-----------|------|
| **FFmpeg** | 멀티미디어 프레임워크 (트랜스코딩, 추출 등) |
| **APAC** | Apple Positional Audio Codec, 공간 오디오 포맷 |
| **MOV 포맷** | QuickTime 기반 컨테이너 |
| **AVFoundation/CoreMedia** | macOS/iOS 기본 미디어 프레임워크 |
| **ffmpeg-windows-build-helpers** | Windows용 FFmpeg 크로스 컴파일 환경 |
| **libavcodec** | FFmpeg의 디코딩/인코딩 라이브러리 |
| **aist#0:1/none** | 디코딩 요청이지만 "none" 코덱으로 인식됨 (즉, FFmpeg이 알지 못함) |

---

## 🧪 재현 방법 (PoC 수준)

1. iPhone 16에서 생성한 `.mov` 파일 확보 (예: APAC 포함)
2. 아래 명령 실행:

```bash
ffmpeg -i IMG_0755.mov -map 0:a output.mov
```

3. 출력:
```
Could not find codec parameters for stream 1 (Audio: none (apac / 0x63617061), ...)
Error opening output file ...
```

4. `-c:a copy` 등으로도 복사 불가능하며, 코덱 정보 부족으로 출력 실패

---

## 🧱 구조 분석

```txt
Stream #0:1[0x2](und): Audio: none (apac / 0x63617061), 48000 Hz, 4.0, 380 kb/s
```

- `Audio: none` → 코덱이 인식되지 않음
- `apac / 0x63617061` → Apple APAC, 코드값 `'apac'`
- `4.0` → 4채널 공간 오디오
- `handler_name: Core Media Audio` → Apple 자체 디코더 필요

---

## 🚧 해결/대응 방안

### 🔹 FFmpeg 개선 제안

- Apple의 `CoreAudioToolbox.framework`, `AudioCodecs.framework`를 참조하여 디코더 구현
- 또는 FFmpeg에 코덱 `apac` 등록 및 샘플 디코더 우회 추가
- 형식은 HOA 기반 Ambisonics로, 단순 PCM은 아님

### 🔹 임시 회피책

- macOS에서 `afconvert`로 AAC로 다시 인코딩 후 FFmpeg 사용
```bash
afconvert -f mp4f -d aac input.mov converted.m4a
```

---

## 📌 결론

이 이슈는 **FFmpeg이 APAC 오디오 트랙을 지원하지 않기 때문에 발생하는 트랜스코딩 실패 현상**입니다.  
공간 오디오가 점점 널리 사용됨에 따라, FFmpeg에서 해당 코덱에 대한 기본 디코딩/우회 지원이 필요합니다.

- 코덱 ID: `'apac'` (`0x63617061`)
- 디코딩 라이브러리 필요: Apple 전용 또는 리버스 엔지니어링
