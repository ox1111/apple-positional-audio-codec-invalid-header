
# File: apac_lldb_hook.py
# Description: LLDB hook script for observing APAC decoding crash context

import lldb

def __lldb_init_module(debugger, internal_dict):
    debugger.HandleCommand('breakpoint set --name DecodeAPACFrame')
    debugger.HandleCommand('breakpoint command add 1 -o "frame variable mRemappingArray"')
    debugger.HandleCommand('breakpoint command add 1 -o "frame variable mChannelLayout"')
    debugger.HandleCommand('breakpoint command add 1 -o "frame variable mTotalComponents"')
    debugger.HandleCommand('breakpoint command add 1 -o "register read"')
    debugger.HandleCommand('breakpoint command add 1 -o "bt"')
    print("[*] DecodeAPACFrame hook installed.")
